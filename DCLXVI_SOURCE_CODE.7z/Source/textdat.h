//HEADER_GOES_HERE
#ifndef __TEXTDAT_H__
#define __TEXTDAT_H__

extern const TextDataStruct alltext[259];
extern const int gdwAllTextEntries;

#endif /* __TEXTDAT_H__ */
