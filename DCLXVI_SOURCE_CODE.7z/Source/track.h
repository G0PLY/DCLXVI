//HEADER_GOES_HERE
#ifndef __TRACK_H__
#define __TRACK_H__

void __cdecl track_process();
void __fastcall track_repeat_walk(BOOL rep);
BOOL __cdecl track_isscrolling();

#endif /* __TRACK_H__ */
