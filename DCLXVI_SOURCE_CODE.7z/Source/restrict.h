//HEADER_GOES_HERE
#ifndef __RESTRICT_H__
#define __RESTRICT_H__

BOOL __cdecl SystemSupported();
BOOL __cdecl RestrictedTest();
BOOL __cdecl ReadOnlyTest();

#endif /* __RESTRICT_H__ */
